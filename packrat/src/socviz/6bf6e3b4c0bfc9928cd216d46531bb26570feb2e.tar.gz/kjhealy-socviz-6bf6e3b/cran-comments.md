## Minor update
This is a minor update of the package, containing fixes to data files and one function.

## Test environments

* Local MacOS install, R 3.6.2 on Catalina 10.15.3
* ubuntu 16.04.6 LTS (on travis-ci), R 3.6.2
* win-builder (devel and release)

## R CMD check results
There were no ERRORs, WARNINGs, or NOTEs.

## Downstream dependencies
This package has no downstream dependencies.
